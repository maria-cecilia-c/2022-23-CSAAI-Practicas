Instrucciones:<br>

-Al cargar la pagina se debera dar al boton de iniciar. <br>
-Se debera seleccionar el angulo y la velocidad del lanzamiento.<br>
-Para realizar el lanzamineto se debera dar al boton que dice "Disparo".<br>
-Si hemos acertado o fallado se debera dar la boton de iniciar para poder jugar otra vez.<br>


Mejoras:<br>

-Se añadio fondos y personajes.<br>
-Al acertar el disparo o fallar se escuchan diferentes sonidos.<br>
